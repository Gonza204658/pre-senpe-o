// ── Elementos ──────────────────────────────────────────────
const navUsuariosBtn     = document.getElementById('nav-usuarios');
const navInventarioBtn   = document.getElementById('nav-inventario');
const vistaUsuarios      = document.getElementById('vista-usuarios');
const usersTbody         = document.getElementById('users-tbody');
const btnCrearUsuario    = document.getElementById('btn-crear-usuario');

const modalUsuario       = document.getElementById('modal-usuario');
const modalUsuarioTit    = document.getElementById('modal-usuario-titulo');
const modalUsuarioGuardar= document.getElementById('modal-usuario-guardar');
const modalUsuarioCerrar = document.getElementById('modal-usuario-cerrar');
const modalUsuarioCxl    = document.getElementById('modal-usuario-cancelar');

const uName     = document.getElementById('u-name');
const uUsername = document.getElementById('u-username');
const uPassword = document.getElementById('u-password');
const uRole     = document.getElementById('u-role');

const API_USERS = '/api/users';

let editandoUserId = null;
let usuarioEditando = null;

// ── Navegación ──────────────────────────────────────────────
navUsuariosBtn.addEventListener('click', (e) => {
  e.preventDefault();
  // Reusar función global de dashboard.js
  mostrarVista('usuarios');
  cargarUsuarios();
});

// ── Cargar tabla ────────────────────────────────────────────
async function cargarUsuarios() {
  usersTbody.innerHTML = `<tr><td colspan="4" class="loading">Cargando usuarios...</td></tr>`;
  try {
    const res   = await fetch(API_USERS);
    const users = await res.json();
    renderizarUsuarios(users);
  } catch {
    usersTbody.innerHTML = `<tr><td colspan="4" class="loading">Error al cargar usuarios.</td></tr>`;
  }
}

function renderizarUsuarios(users) {
  if (users.length === 0) {
    usersTbody.innerHTML = `<tr><td colspan="4" class="empty">No hay usuarios.</td></tr>`;
    return;
  }

  usersTbody.innerHTML = users.map(u => `
    <tr>
      <td>
        <div class="td-avatar">
          <div class="user-avatar">${u.name.charAt(0).toUpperCase()}</div>
          <span>${u.name}</span>
        </div>
      </td>
      <td class="td-muted">@${u.username}</td>
      <td><span class="badge badge-${u.role}">${u.role}</span></td>
      <td style="text-align:right">
        <div class="actions" style="justify-content:flex-end">
          <button class="btn btn-secondary btn-sm" data-editar-user="${u.id}">Editar</button>
          <button class="btn btn-danger btn-sm" data-borrar-user="${u.id}" data-nombre-user="${u.name}">Borrar</button>
        </div>
      </td>
    </tr>
  `).join('');

  // Editar usuario
  usersTbody.querySelectorAll('[data-editar-user]').forEach(btn => {
    btn.addEventListener('click', () => {
      const u = users.find(u => u.id == btn.dataset.editarUser);
      if (u) abrirModalUsuario(u);
    });
  });

  // Borrar usuario
  usersTbody.querySelectorAll('[data-borrar-user]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!confirm(`¿Eliminar al usuario "${btn.dataset.nombreUser}"?`)) return;
      borrarUsuario(btn.dataset.borrarUser);
    });
  });
}

// ── Modal Usuario ───────────────────────────────────────────
function abrirModalUsuario(user = null) {
  editandoUserId  = user ? user.id : null;
  usuarioEditando = user;

  if (user) {
    modalUsuarioTit.textContent     = 'Editar Usuario';
    modalUsuarioGuardar.textContent = 'Guardar Cambios';
    uName.value     = user.name;
    uUsername.value = user.username;
    uPassword.value = '';
    uPassword.placeholder = '•••••••• (dejar vacío para no cambiar)';
    uRole.value     = user.role;
  } else {
    modalUsuarioTit.textContent     = 'Crear Usuario';
    modalUsuarioGuardar.textContent = 'Crear Usuario';
    uName.value = uUsername.value = uPassword.value = '';
    uPassword.placeholder = '••••••••';
    uRole.value = 'empleado';
  }

  modalUsuario.classList.remove('hidden');
}

function cerrarModalUsuario() {
  modalUsuario.classList.add('hidden');
  editandoUserId  = null;
  usuarioEditando = null;
}

btnCrearUsuario.addEventListener('click', () => abrirModalUsuario(null));
modalUsuarioCerrar.addEventListener('click', cerrarModalUsuario);
modalUsuarioCxl.addEventListener('click', cerrarModalUsuario);
modalUsuario.addEventListener('click', cerrarModalUsuario);
document.querySelector('#modal-usuario .modal').addEventListener('click', e => e.stopPropagation());

modalUsuarioGuardar.addEventListener('click', async () => {
  const nombre   = uName.value.trim();
  const username = uUsername.value.trim();
  const password = uPassword.value.trim();
  const role     = uRole.value;

  if (!nombre || !username) {
    alert('Nombre y username son obligatorios.');
    return;
  }

  if (!editandoUserId && !password) {
    alert('La contraseña es obligatoria para crear un usuario.');
    return;
  }

  let body;

  if (editandoUserId) {
    body = {
      id: String(editandoUserId),
      name: nombre,
      username,
      password: password || usuarioEditando.password,
      role
    };
    await fetch(`${API_USERS}/${editandoUserId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } else {
    body = { name: nombre, username, password, role };
    await fetch(API_USERS, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  }

  cerrarModalUsuario();
  cargarUsuarios();
});

// ── Borrar ──────────────────────────────────────────────────
async function borrarUsuario(id) {
  try {
    await fetch(`${API_USERS}/${id}`, { method: 'DELETE' });
  } catch {
    alert('Error al eliminar el usuario.');
  }
  cargarUsuarios();
}
