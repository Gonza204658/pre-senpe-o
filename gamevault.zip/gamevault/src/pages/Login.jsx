import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import './Login.css'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const { login, loading, error } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    const ok = await login(username, password)
    if (ok) navigate('/dashboard')
  }

  return (
    <div className="login-page">
      <div className="login-bg">
        <div className="login-bg-text">GAMEVAULT</div>
      </div>

      <div className="login-card animate-in">
        <div className="login-logo">🎮</div>
        <h1 className="login-title">GAME<span>VAULT</span></h1>
        <p className="login-subtitle">Sistema de Inventario</p>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label className="form-label">Usuario</label>
            <input
              className="form-input"
              type="text"
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="Ingresa tu usuario"
              required
              autoFocus
            />
          </div>
          <div className="form-group">
            <label className="form-label">Contraseña</label>
            <input
              className="form-input"
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Ingresa tu contraseña"
              required
            />
          </div>

          {error && <div className="login-error">⚠ {error}</div>}

          <button className="btn btn-primary login-btn" type="submit" disabled={loading}>
            {loading ? 'Entrando...' : 'Iniciar Sesión'}
          </button>
        </form>

        <div className="login-hint">
          <p><strong>Admin:</strong> admin / admin123</p>
          <p><strong>Empleado:</strong> empleado / emp123</p>
        </div>
      </div>
    </div>
  )
}
