// ── Selección de elementos del DOM ─────────────────────────
const form     = document.getElementById('loginForm');  // formulario de login
const btnLogin = document.getElementById('login-btn');  // botón de submit
const errorBox = document.getElementById('login-error'); // caja de error visible al usuario

// Escucha el evento "submit" del formulario
form.addEventListener('submit', async (e) => {
  e.preventDefault(); // evita que la página se recargue al enviar el formulario

  // Lee los valores del formulario y elimina espacios extra
  const username = form.username.value.trim();
  const password = form.password.value.trim();

  // Deshabilita el botón mientras se procesa para evitar doble envío
  btnLogin.disabled    = true;
  btnLogin.textContent = 'Entrando...';
  errorBox.classList.add('hidden'); // oculta cualquier error anterior

  try {
    // Consulta la API buscando un usuario que coincida con username y password
    const res   = await fetch(`/api/users?username=${username}&password=${password}`);
    const users = await res.json(); // convierte la respuesta a array de objetos

    // Si no encontró ningún usuario, muestra error y corta la ejecución
    if (users.length === 0) {
      errorBox.textContent = '⚠ Usuario o contraseña incorrectos';
      errorBox.classList.remove('hidden');
      return;
    }

    // Desestructura para excluir la contraseña antes de guardar la sesión
    // "password: _" la saca del objeto, "...safeUser" guarda el resto
    const { password: _, ...safeUser } = users[0];

    // Guarda el usuario (sin contraseña) en localStorage para persistir la sesión
    localStorage.setItem('gamevault_user', JSON.stringify(safeUser));

    // Dispara un evento personalizado que escucha dashboard.js para iniciar la app
    window.dispatchEvent(new CustomEvent('gv:login', { detail: safeUser }));

  } catch {
    // Si el fetch falla (ej: servidor apagado), muestra error de conexión
    errorBox.textContent = '⚠ Error al conectar con el servidor';
    errorBox.classList.remove('hidden');
  } finally {
    // Siempre vuelve a habilitar el botón, haya error o no
    btnLogin.disabled    = false;
    btnLogin.textContent = 'Iniciar Sesión';
  }
});
