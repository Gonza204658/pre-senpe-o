import { useState, useEffect } from 'react'
import './Modal.css'

const EMPTY = {
  title: '', platform: '', genre: '', price: '', stock: '', year: '', publisher: '', condition: 'Nuevo'
}

const PLATFORMS = ['PC', 'PS5', 'PS4', 'Xbox Series X', 'Xbox One', 'Nintendo Switch', 'Otro']
const GENRES = ['Acción', 'Acción/Aventura', 'RPG', 'FPS', 'Deportes', 'Estrategia', 'Terror', 'Plataformas', 'Otro']

export default function GameModal({ game, onSave, onClose }) {
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (game) setForm({ ...game })
    else setForm(EMPTY)
  }, [game])

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    await onSave({
      ...form,
      price: parseFloat(form.price),
      stock: parseInt(form.stock),
      year: parseInt(form.year)
    })
    setSaving(false)
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">{game ? 'Editar Juego' : 'Agregar Juego'}</h2>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        <form onSubmit={handleSubmit} className="modal-form">
          <div className="form-row">
            <div className="form-group" style={{gridColumn: '1/-1'}}>
              <label className="form-label">Título</label>
              <input className="form-input" name="title" value={form.title} onChange={handleChange} required placeholder="Nombre del juego" />
            </div>

            <div className="form-group">
              <label className="form-label">Plataforma</label>
              <select className="form-input" name="platform" value={form.platform} onChange={handleChange} required>
                <option value="">Seleccionar...</option>
                {PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Género</label>
              <select className="form-input" name="genre" value={form.genre} onChange={handleChange} required>
                <option value="">Seleccionar...</option>
                {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Precio ($)</label>
              <input className="form-input" name="price" type="number" step="0.01" min="0" value={form.price} onChange={handleChange} required placeholder="0.00" />
            </div>

            <div className="form-group">
              <label className="form-label">Stock</label>
              <input className="form-input" name="stock" type="number" min="0" value={form.stock} onChange={handleChange} required placeholder="0" />
            </div>

            <div className="form-group">
              <label className="form-label">Año</label>
              <input className="form-input" name="year" type="number" min="1970" max="2030" value={form.year} onChange={handleChange} required placeholder="2024" />
            </div>

            <div className="form-group">
              <label className="form-label">Editorial</label>
              <input className="form-input" name="publisher" value={form.publisher} onChange={handleChange} required placeholder="Ej: Nintendo" />
            </div>

            <div className="form-group" style={{gridColumn: '1/-1'}}>
              <label className="form-label">Condición</label>
              <div className="radio-group">
                {['Nuevo', 'Usado'].map(c => (
                  <label key={c} className={`radio-option ${form.condition === c ? 'active' : ''}`}>
                    <input type="radio" name="condition" value={c} checked={form.condition === c} onChange={handleChange} />
                    {c}
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? 'Guardando...' : (game ? 'Guardar Cambios' : 'Agregar Juego')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
