# 🎮 GameVault — Sistema de Inventario

Sistema de inventario para una tienda de videojuegos. Construido con **Vanilla JS + Vite + JSON Server**, sin frameworks ni carpetas anidadas.

---

## 🚀 Instalación y uso

### Requisitos
- Node.js 18+
- npm

### Pasos

```bash
# 1. Instalar dependencias
npm install

# 2. Correr el proyecto completo (frontend + API al mismo tiempo)
npm run dev
```

| Servicio  | URL                     |
|-----------|-------------------------|
| Frontend  | http://localhost:5173   |
| API       | http://localhost:3000   |

### Comandos disponibles

```bash
npm run dev      # Corre frontend + API simultáneamente
npm run api      # Corre solo JSON Server (API)
npm run build    # Compila el frontend para producción
```

---

## 🔑 Credenciales de prueba

| Usuario    | Contraseña | Rol      |
|------------|------------|----------|
| `admin`    | `admin123` | Admin    |
| `empleado` | `emp123`   | Empleado |

---

## 📁 Estructura del proyecto

```
gamevault/
├── index.html      ← Toda la UI: login, dashboard e inventario en un solo archivo
├── login.js        ← Lógica de autenticación y sesión
├── dashboard.js    ← Inventario: carga, filtros, CRUD de juegos, stats
├── panelAdmin.js   ← Gestión de usuarios (solo accesible para admin)
├── db.json         ← Base de datos mock (JSON Server)
├── package.json    ← Dependencias y scripts
└── vite.config.js  ← Configuración de Vite con proxy a la API
```

> Sin `src/`, sin componentes, sin contextos. Todo plano y directo al grano.

---

## 🏗️ Cómo funciona la app

### Una sola página (SPA manual)
Todo el HTML vive en `index.html`. Las "vistas" son secciones con la clase `hidden` que se muestran u ocultan según el estado. No hay navegación real por URLs.

```
#vista-login      → pantalla de inicio de sesión
#vista-app        → navbar + contenido principal
  #vista-inventario → tabla de juegos con stats y filtros
  #vista-usuarios   → gestión de usuarios (solo admin)
```

### Comunicación entre archivos JS
Los tres archivos JS (`login.js`, `dashboard.js`, `panelAdmin.js`) se cargan como módulos independientes. Se comunican usando **eventos personalizados** del navegador:

```js
// login.js dispara este evento al autenticarse exitosamente
window.dispatchEvent(new CustomEvent('gv:login', { detail: safeUser }));

// dashboard.js lo escucha y arranca la app
window.addEventListener('gv:login', (e) => iniciarSesion(e.detail));
```

### Proxy de Vite
`vite.config.js` redirige todas las peticiones `/api/*` al servidor JSON Server en el puerto 3000. Esto evita errores de CORS en desarrollo:

```
fetch('/api/games')  →  http://localhost:3000/games
```

---

## 🔐 Sesión y persistencia

La sesión se guarda en `localStorage` bajo la clave `gamevault_user`, **sin la contraseña**:

```js
// Guardar al iniciar sesión
localStorage.setItem('gamevault_user', JSON.stringify(safeUser));

// Recuperar al recargar la página
const savedUser = localStorage.getItem('gamevault_user');
if (savedUser) iniciarSesion(JSON.parse(savedUser));

// Borrar al cerrar sesión
localStorage.removeItem('gamevault_user');
```

---

## 👥 Roles y permisos

Los permisos se aplican dinámicamente en `dashboard.js` según el rol del usuario guardado en sesión.

| Acción              | Admin | Empleado |
|---------------------|-------|----------|
| Ver inventario      | ✅    | ✅       |
| Editar stock (+/-)  | ✅    | ✅       |
| Editar juego        | ✅    | ✅       |
| Agregar juego       | ✅    | ❌       |
| Eliminar juego      | ✅    | ❌       |
| Ver panel usuarios  | ✅    | ❌       |
| Crear/editar usuarios | ✅  | ❌       |

---

## 🔄 API — Endpoints usados

La API es **JSON Server** leyendo `db.json`. Vite la expone bajo `/api`.

| Método   | Endpoint            | Descripción                      | Quién puede |
|----------|---------------------|----------------------------------|-------------|
| `GET`    | `/api/games`        | Listar todos los juegos          | Todos       |
| `POST`   | `/api/games`        | Crear un juego nuevo             | Solo admin  |
| `PUT`    | `/api/games/:id`    | Reemplazar un juego completo     | Todos       |
| `PATCH`  | `/api/games/:id`    | Actualizar solo el stock         | Todos       |
| `DELETE` | `/api/games/:id`    | Eliminar un juego                | Solo admin  |
| `GET`    | `/api/users?username=X&password=Y` | Login: buscar usuario | — |
| `GET`    | `/api/users`        | Listar usuarios                  | Solo admin  |
| `POST`   | `/api/users`        | Crear usuario                    | Solo admin  |
| `PUT`    | `/api/users/:id`    | Editar usuario                   | Solo admin  |
| `DELETE` | `/api/users/:id`    | Eliminar usuario                 | Solo admin  |

---

## ⚡ Actualización optimista de stock

Cuando se pulsa `+` o `−` en el stock de un juego, la UI se actualiza **inmediatamente** sin esperar a la API. Luego se sincroniza en segundo plano con un `PATCH`. Esto hace la interfaz sentirse más rápida:

```js
juego.stock = nuevoStock;  // 1. actualiza el dato en memoria
renderizarTabla();          // 2. redibuja la tabla al instante
await fetch(...)            // 3. sincroniza con la API (en segundo plano)
```

---

## 📦 Dependencias

| Paquete        | Versión  | Uso                              |
|----------------|----------|----------------------------------|
| `vite`         | ^5.0.0   | Servidor de desarrollo y bundler |
| `json-server`  | ^0.17.0  | API REST mock sobre `db.json`    |
| `concurrently` | ^8.0.0   | Corre Vite y JSON Server juntos  |
