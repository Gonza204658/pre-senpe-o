import { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    // Persistencia de sesión: leer de localStorage al iniciar
    const saved = localStorage.getItem('gamevault_user')
    return saved ? JSON.parse(saved) : null
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const login = async (username, password) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/users?username=${username}`)
      const users = await res.json()
      const found = users.find(u => u.password === password)
      if (!found) {
        setError('Usuario o contraseña incorrectos')
        return false
      }
      // Guardar en estado y localStorage (sin la contraseña)
      const { password: _, ...safeUser } = found
      setUser(safeUser)
      localStorage.setItem('gamevault_user', JSON.stringify(safeUser))
      return true
    } catch (e) {
      setError('Error al conectar con el servidor')
      return false
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('gamevault_user')
  }

  // Helpers de permisos
  const isAdmin = user?.role === 'admin'
  const can = {
    create: isAdmin,
    edit: !!user,       // admin y empleado
    delete: isAdmin,
    viewAll: !!user,
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, error, can, isAdmin }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
