// ── Elementos ──────────────────────────────────────────────
const vistaLogin      = document.getElementById('vista-login');
const vistaApp        = document.getElementById('vista-app');
const vistaInventario = document.getElementById('vista-inventario');
const navInventario   = document.getElementById('nav-inventario');
const navUsuarios     = document.getElementById('nav-usuarios');
const userNameDisplay = document.getElementById('user-name-display');
const userBadge       = document.getElementById('user-badge');
const btnLogout       = document.getElementById('btn-logout');
const btnAgregar      = document.getElementById('btn-agregar');
const searchInput     = document.getElementById('search-input');
const filterPlatform  = document.getElementById('filter-platform');
const gamesTbody      = document.getElementById('games-tbody');

// Stats
const statTitulos = document.getElementById('stat-titulos');
const statStock   = document.getElementById('stat-stock');
const statBajo    = document.getElementById('stat-bajo');
const statCardBajo= document.getElementById('stat-card-bajo');
const statValor   = document.getElementById('stat-valor');

// Modal juego
const modalJuego    = document.getElementById('modal-juego');
const modalJuegoTit = document.getElementById('modal-juego-titulo');
const modalJuegoBtn = document.getElementById('modal-juego-guardar');
const jTitle        = document.getElementById('j-title');
const jPlatform     = document.getElementById('j-platform');
const jGenre        = document.getElementById('j-genre');
const jPrice        = document.getElementById('j-price');
const jStock        = document.getElementById('j-stock');
const jYear         = document.getElementById('j-year');
const jPublisher    = document.getElementById('j-publisher');
const radioNuevo    = document.getElementById('radio-nuevo');
const radioUsado    = document.getElementById('radio-usado');

// Modal confirm
const modalConfirm  = document.getElementById('modal-confirm');
const confirmMsg    = document.getElementById('confirm-msg');
const confirmOk     = document.getElementById('confirm-ok');
const confirmCancel = document.getElementById('confirm-cancelar');

// ── Estado ──────────────────────────────────────────────────
let todosLosJuegos  = [];
let editandoJuegoId = null;
let confirmCallback = null;
let usuario         = null;

// ── Inicialización ─────────────────────────────────────────
function iniciarSesion(user) {
  usuario = user;
  const isAdmin = user.role === 'admin';

  // Mostrar app, ocultar login
  vistaLogin.classList.add('hidden');
  vistaApp.classList.remove('hidden');

  // Navbar
  userNameDisplay.textContent = user.name;
  userBadge.textContent       = user.role;
  userBadge.className         = `badge badge-${user.role}`;
  if (isAdmin) navUsuarios.classList.remove('hidden');
  else         navUsuarios.classList.add('hidden');

  // Permisos
  if (isAdmin) btnAgregar.classList.remove('hidden');
  else         btnAgregar.classList.add('hidden');

  cargarJuegos();
}

function cerrarSesion() {
  localStorage.removeItem('gamevault_user');
  usuario = null;
  vistaApp.classList.add('hidden');
  vistaLogin.classList.remove('hidden');
  document.querySelector('#loginForm').reset();
  document.getElementById('login-error').classList.add('hidden');
}

// ── Sesión persistente ──────────────────────────────────────
const savedUser = localStorage.getItem('gamevault_user');
if (savedUser) iniciarSesion(JSON.parse(savedUser));

window.addEventListener('gv:login', (e) => iniciarSesion(e.detail));
btnLogout.addEventListener('click', cerrarSesion);

// ── Navegación ──────────────────────────────────────────────
navInventario.addEventListener('click', (e) => {
  e.preventDefault();
  mostrarVista('inventario');
});

function mostrarVista(vista) {
  document.getElementById('vista-inventario').classList.toggle('hidden', vista !== 'inventario');
  document.getElementById('vista-usuarios').classList.toggle('hidden',   vista !== 'usuarios');
  navInventario.classList.toggle('active', vista === 'inventario');
  navUsuarios.classList.toggle('active',   vista === 'usuarios');
}

// ── API helpers ─────────────────────────────────────────────
const API = '/api/games';

async function cargarJuegos() {
  gamesTbody.innerHTML = `<tr><td colspan="8" class="loading">Cargando inventario...</td></tr>`;
  try {
    const res  = await fetch(API);
    todosLosJuegos = await res.json();
    poblarFiltros();
    renderizarTabla();
  } catch {
    gamesTbody.innerHTML = `<tr><td colspan="8" class="loading">Error al cargar datos.</td></tr>`;
  }
}

function poblarFiltros() {
  const plataformas = [...new Set(todosLosJuegos.map(g => g.platform))];
  filterPlatform.innerHTML = `<option value="">Todas las plataformas</option>` +
    plataformas.map(p => `<option value="${p}">${p}</option>`).join('');
}

function filtrados() {
  const q  = searchInput.value.toLowerCase();
  const pl = filterPlatform.value;
  return todosLosJuegos.filter(g => {
    const matchQ  = g.title.toLowerCase().includes(q) || g.publisher.toLowerCase().includes(q);
    const matchPl = !pl || g.platform === pl;
    return matchQ && matchPl;
  });
}

function renderizarTabla() {
  const lista = filtrados();
  actualizarStats();

  const isAdmin = usuario?.role === 'admin';

  if (lista.length === 0) {
    gamesTbody.innerHTML = `<tr><td colspan="8" class="empty">No se encontraron juegos</td></tr>`;
    return;
  }

  gamesTbody.innerHTML = lista.map(g => `
    <tr class="${g.stock <= 3 ? 'row-warning' : ''}">
      <td>
        <span class="game-title">${g.title}</span>
        <span class="game-year">${g.year}</span>
      </td>
      <td><span class="platform-tag">${g.platform}</span></td>
      <td class="td-genre">${g.genre}</td>
      <td class="td-muted">${g.publisher}</td>
      <td><span class="badge badge-${g.condition.toLowerCase()}">${g.condition}</span></td>
      <td class="td-price">$${g.price.toFixed(2)}</td>
      <td>
        <div class="stock-control">
          <button class="stock-btn" data-id="${g.id}" data-delta="-1">−</button>
          <span class="stock-num ${g.stock <= 3 ? 'stock-low' : ''}">${g.stock}</span>
          <button class="stock-btn" data-id="${g.id}" data-delta="1">+</button>
        </div>
      </td>
      <td>
        <div class="actions">
          <button class="btn btn-secondary btn-sm" data-editar="${g.id}">Editar</button>
          ${isAdmin ? `<button class="btn btn-danger btn-sm" data-borrar="${g.id}" data-nombre="${g.title}">Borrar</button>` : ''}
        </div>
      </td>
    </tr>
  `).join('');

  // Stock +/−
  gamesTbody.querySelectorAll('.stock-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id    = btn.dataset.id;
      const delta = parseInt(btn.dataset.delta);
      cambiarStock(id, delta);
    });
  });

  // Editar
  gamesTbody.querySelectorAll('[data-editar]').forEach(btn => {
    btn.addEventListener('click', () => abrirModalEditar(btn.dataset.editar));
  });

  // Borrar
  gamesTbody.querySelectorAll('[data-borrar]').forEach(btn => {
    btn.addEventListener('click', () => {
      abrirConfirm(`Se eliminará "${btn.dataset.nombre}" del inventario.`, () => borrarJuego(btn.dataset.borrar));
    });
  });
}

function actualizarStats() {
  const total  = todosLosJuegos.length;
  const stock  = todosLosJuegos.reduce((s, g) => s + g.stock, 0);
  const bajo   = todosLosJuegos.filter(g => g.stock <= 3).length;
  const valor  = todosLosJuegos.reduce((s, g) => s + g.price * g.stock, 0);

  statTitulos.textContent = total;
  statStock.textContent   = stock;
  statBajo.textContent    = bajo;
  statValor.textContent   = `$${valor.toFixed(0)}`;
  statCardBajo.classList.toggle('stat-warning', bajo > 0);
}

async function cambiarStock(id, delta) {
  const juego = todosLosJuegos.find(g => g.id == id);
  if (!juego) return;
  const nuevoStock = Math.max(0, juego.stock + delta);

  // Actualizar local inmediatamente
  juego.stock = nuevoStock;
  renderizarTabla();

  // Sincronizar con API
  await fetch(`${API}/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ stock: nuevoStock })
  });
}

async function borrarJuego(id) {
  await fetch(`${API}/${id}`, { method: 'DELETE' });
  cerrarConfirm();
  cargarJuegos();
}

searchInput.addEventListener('input', renderizarTabla);
filterPlatform.addEventListener('change', renderizarTabla);

// ── Modal Juego ─────────────────────────────────────────────
function abrirModalCrear() {
  editandoJuegoId          = null;
  modalJuegoTit.textContent = 'Agregar Juego';
  modalJuegoBtn.textContent = 'Agregar Juego';
  jTitle.value = jPlatform.value = jGenre.value = jPrice.value = jStock.value = jYear.value = jPublisher.value = '';
  setCondicion('Nuevo');
  modalJuego.classList.remove('hidden');
}

function abrirModalEditar(id) {
  const g = todosLosJuegos.find(g => g.id == id);
  if (!g) return;
  editandoJuegoId           = g.id;
  modalJuegoTit.textContent = 'Editar Juego';
  modalJuegoBtn.textContent = 'Guardar Cambios';
  jTitle.value     = g.title;
  jPlatform.value  = g.platform;
  jGenre.value     = g.genre;
  jPrice.value     = g.price;
  jStock.value     = g.stock;
  jYear.value      = g.year;
  jPublisher.value = g.publisher;
  setCondicion(g.condition);
  modalJuego.classList.remove('hidden');
}

function cerrarModalJuego() {
  modalJuego.classList.add('hidden');
}

function setCondicion(val) {
  const radios = document.querySelectorAll('input[name="condition"]');
  radios.forEach(r => {
    r.checked = (r.value === val);
  });
  radioNuevo.classList.toggle('active', val === 'Nuevo');
  radioUsado.classList.toggle('active', val === 'Usado');
}

document.querySelectorAll('input[name="condition"]').forEach(r => {
  r.addEventListener('change', () => setCondicion(r.value));
});

btnAgregar.addEventListener('click', abrirModalCrear);
document.getElementById('modal-juego-cerrar').addEventListener('click', cerrarModalJuego);
document.getElementById('modal-juego-cancelar').addEventListener('click', cerrarModalJuego);
modalJuego.addEventListener('click', cerrarModalJuego);

modalJuegoBtn.addEventListener('click', async () => {
  const condition = document.querySelector('input[name="condition"]:checked')?.value || 'Nuevo';
  const datos = {
    title:     jTitle.value.trim(),
    platform:  jPlatform.value,
    genre:     jGenre.value,
    price:     parseFloat(jPrice.value),
    stock:     parseInt(jStock.value),
    year:      parseInt(jYear.value),
    publisher: jPublisher.value.trim(),
    condition
  };

  if (!datos.title || !datos.platform || !datos.genre || isNaN(datos.price) || isNaN(datos.stock)) {
    alert('Por favor completa todos los campos obligatorios.');
    return;
  }

  if (editandoJuegoId) {
    await fetch(`${API}/${editandoJuegoId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...datos, id: editandoJuegoId })
    });
  } else {
    await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    });
  }

  cerrarModalJuego();
  cargarJuegos();
});

// ── Modal Confirm ───────────────────────────────────────────
function abrirConfirm(msg, callback) {
  confirmMsg.textContent = msg;
  confirmCallback        = callback;
  modalConfirm.classList.remove('hidden');
}

function cerrarConfirm() {
  modalConfirm.classList.add('hidden');
  confirmCallback = null;
}

confirmOk.addEventListener('click', () => { if (confirmCallback) confirmCallback(); });
confirmCancel.addEventListener('click', cerrarConfirm);
modalConfirm.addEventListener('click', cerrarConfirm);
document.querySelector('#modal-confirm .confirm-dialog').addEventListener('click', e => e.stopPropagation());
