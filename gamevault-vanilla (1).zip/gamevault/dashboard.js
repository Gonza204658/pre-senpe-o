// ── Selección de elementos del DOM ─────────────────────────
// Vistas principales (secciones que se muestran/ocultan)
const vistaLogin      = document.getElementById('vista-login');
const vistaApp        = document.getElementById('vista-app');
const vistaInventario = document.getElementById('vista-inventario');

// Navegación (enlaces del navbar)
const navInventario   = document.getElementById('nav-inventario');
const navUsuarios     = document.getElementById('nav-usuarios');

// Navbar: info del usuario y botón de salir
const userNameDisplay = document.getElementById('user-name-display');
const userBadge       = document.getElementById('user-badge');
const btnLogout       = document.getElementById('btn-logout');
const btnAgregar      = document.getElementById('btn-agregar'); // solo visible para admin

// Controles de búsqueda y filtro
const searchInput    = document.getElementById('search-input');
const filterPlatform = document.getElementById('filter-platform');

// Cuerpo de la tabla de juegos
const gamesTbody = document.getElementById('games-tbody');

// Tarjetas de estadísticas
const statTitulos  = document.getElementById('stat-titulos');
const statStock    = document.getElementById('stat-stock');
const statBajo     = document.getElementById('stat-bajo');
const statCardBajo = document.getElementById('stat-card-bajo');
const statValor    = document.getElementById('stat-valor');

// Elementos del modal de crear/editar juego
const modalJuego    = document.getElementById('modal-juego');
const modalJuegoTit = document.getElementById('modal-juego-titulo');
const modalJuegoBtn = document.getElementById('modal-juego-guardar');
const jTitle        = document.getElementById('j-title');
const jPlatform     = document.getElementById('j-platform');
const jGenre        = document.getElementById('j-genre');
const jPrice        = document.getElementById('j-price');
const jStock        = document.getElementById('j-stock');
const jYear         = document.getElementById('j-year');
const jPublisher    = document.getElementById('j-publisher');
const radioNuevo    = document.getElementById('radio-nuevo');
const radioUsado    = document.getElementById('radio-usado');

// Elementos del modal de confirmación (borrar juego)
const modalConfirm  = document.getElementById('modal-confirm');
const confirmMsg    = document.getElementById('confirm-msg');
const confirmOk     = document.getElementById('confirm-ok');
const confirmCancel = document.getElementById('confirm-cancelar');

// ── Estado global ───────────────────────────────────────────
let todosLosJuegos  = []; // array con todos los juegos cargados desde la API
let editandoJuegoId = null; // id del juego en edición (null = modo crear)
let confirmCallback = null; // función a ejecutar si el usuario confirma el borrado
let usuario         = null; // objeto del usuario actualmente logueado

// ── Iniciar sesión ──────────────────────────────────────────
// Se llama tanto en login nuevo como al recuperar sesión de localStorage
function iniciarSesion(user) {
  usuario = user; // guarda el usuario en el estado global
  const isAdmin = user.role === 'admin'; // booleano para controlar permisos

  // Cambia las vistas: oculta login y muestra la app
  vistaLogin.classList.add('hidden');
  vistaApp.classList.remove('hidden');

  // Muestra nombre y badge de rol en el navbar
  userNameDisplay.textContent = user.name;
  userBadge.textContent       = user.role;
  userBadge.className         = `badge badge-${user.role}`; // aplica color según rol

  // Solo el admin ve el enlace de Usuarios en el navbar
  if (isAdmin) navUsuarios.classList.remove('hidden');
  else         navUsuarios.classList.add('hidden');

  // Solo el admin ve el botón "+ Agregar Juego"
  if (isAdmin) btnAgregar.classList.remove('hidden');
  else         btnAgregar.classList.add('hidden');

  cargarJuegos(); // carga el inventario desde la API al entrar
}

// ── Cerrar sesión ───────────────────────────────────────────
function cerrarSesion() {
  localStorage.removeItem('gamevault_user'); // borra la sesión guardada
  usuario = null; // limpia el estado global
  vistaApp.classList.add('hidden');
  vistaLogin.classList.remove('hidden');
  document.querySelector('#loginForm').reset(); // limpia los campos del formulario
  document.getElementById('login-error').classList.add('hidden');
}

// ── Sesión persistente ──────────────────────────────────────
// Al cargar la página, revisa si había una sesión activa en localStorage
const savedUser = localStorage.getItem('gamevault_user');
if (savedUser) iniciarSesion(JSON.parse(savedUser)); // si existe, inicia sesión directamente

// Escucha el evento personalizado que dispara login.js tras autenticarse
window.addEventListener('gv:login', (e) => iniciarSesion(e.detail));

// Botón Salir: cierra sesión al hacer clic
btnLogout.addEventListener('click', cerrarSesion);

// ── Navegación entre vistas ─────────────────────────────────
navInventario.addEventListener('click', (e) => {
  e.preventDefault();
  mostrarVista('inventario'); // activa la vista del inventario
});

// Alterna entre vista "inventario" y vista "usuarios"
// Agrega/quita la clase "hidden" y marca el nav activo
function mostrarVista(vista) {
  document.getElementById('vista-inventario').classList.toggle('hidden', vista !== 'inventario');
  document.getElementById('vista-usuarios').classList.toggle('hidden',   vista !== 'usuarios');
  navInventario.classList.toggle('active', vista === 'inventario');
  navUsuarios.classList.toggle('active',   vista === 'usuarios');
}

// ── API ─────────────────────────────────────────────────────
const API = '/api/games'; // ruta base de la API (JSON Server con proxy Vite)

// Obtiene todos los juegos de la API y actualiza el estado y la UI
async function cargarJuegos() {
  gamesTbody.innerHTML = `<tr><td colspan="8" class="loading">Cargando inventario...</td></tr>`;
  try {
    const res      = await fetch(API);
    todosLosJuegos = await res.json(); // guarda los juegos en el estado global
    poblarFiltros();   // llena el selector de plataformas con los datos reales
    renderizarTabla(); // dibuja las filas de la tabla
  } catch {
    gamesTbody.innerHTML = `<tr><td colspan="8" class="loading">Error al cargar datos.</td></tr>`;
  }
}

// Extrae las plataformas únicas de los juegos y las inyecta en el <select>
function poblarFiltros() {
  const plataformas = [...new Set(todosLosJuegos.map(g => g.platform))]; // Set elimina duplicados
  filterPlatform.innerHTML = `<option value="">Todas las plataformas</option>` +
    plataformas.map(p => `<option value="${p}">${p}</option>`).join('');
}

// Devuelve los juegos que pasan los filtros activos (búsqueda + plataforma)
function filtrados() {
  const q  = searchInput.value.toLowerCase();  // texto del buscador en minúsculas
  const pl = filterPlatform.value;             // plataforma seleccionada (vacío = todas)
  return todosLosJuegos.filter(g => {
    const matchQ  = g.title.toLowerCase().includes(q) || g.publisher.toLowerCase().includes(q);
    const matchPl = !pl || g.platform === pl;
    return matchQ && matchPl; // el juego pasa si cumple ambos filtros
  });
}

// Dibuja las filas de la tabla con los juegos filtrados y recalcula las stats
function renderizarTabla() {
  const lista   = filtrados();
  actualizarStats(); // recalcula los números de las tarjetas
  const isAdmin = usuario?.role === 'admin';

  if (lista.length === 0) {
    gamesTbody.innerHTML = `<tr><td colspan="8" class="empty">No se encontraron juegos</td></tr>`;
    return;
  }

  // Genera el HTML de cada fila usando template literals
  // La fila se pinta de rojo suave si el stock es <= 3
  gamesTbody.innerHTML = lista.map(g => `
    <tr class="${g.stock <= 3 ? 'row-warning' : ''}">
      <td>
        <span class="game-title">${g.title}</span>
        <span class="game-year">${g.year}</span>
      </td>
      <td><span class="platform-tag">${g.platform}</span></td>
      <td class="td-genre">${g.genre}</td>
      <td class="td-muted">${g.publisher}</td>
      <td><span class="badge badge-${g.condition.toLowerCase()}">${g.condition}</span></td>
      <td class="td-price">$${g.price.toFixed(2)}</td>
      <td>
        <div class="stock-control">
          <!-- data-id y data-delta se leen en el event listener para saber qué juego y cuánto cambiar -->
          <button class="stock-btn" data-id="${g.id}" data-delta="-1">−</button>
          <span class="stock-num ${g.stock <= 3 ? 'stock-low' : ''}">${g.stock}</span>
          <button class="stock-btn" data-id="${g.id}" data-delta="1">+</button>
        </div>
      </td>
      <td>
        <div class="actions">
          <button class="btn btn-secondary btn-sm" data-editar="${g.id}">Editar</button>
          <!-- El botón Borrar solo se inyecta si el usuario es admin -->
          ${isAdmin ? `<button class="btn btn-danger btn-sm" data-borrar="${g.id}" data-nombre="${g.title}">Borrar</button>` : ''}
        </div>
      </td>
    </tr>
  `).join('');

  // Event listeners para los botones de stock (se reasignan cada vez que se re-renderiza)
  gamesTbody.querySelectorAll('.stock-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id    = btn.dataset.id;              // id del juego
      const delta = parseInt(btn.dataset.delta); // +1 o -1
      cambiarStock(id, delta);
    });
  });

  // Event listeners para botones Editar
  gamesTbody.querySelectorAll('[data-editar]').forEach(btn => {
    btn.addEventListener('click', () => abrirModalEditar(btn.dataset.editar));
  });

  // Event listeners para botones Borrar (solo visibles para admin)
  gamesTbody.querySelectorAll('[data-borrar]').forEach(btn => {
    btn.addEventListener('click', () => {
      // Abre el modal de confirmación con un mensaje y la función a ejecutar si acepta
      abrirConfirm(`Se eliminará "${btn.dataset.nombre}" del inventario.`, () => borrarJuego(btn.dataset.borrar));
    });
  });
}

// Recalcula y actualiza las 4 tarjetas de estadísticas
function actualizarStats() {
  const total = todosLosJuegos.length;
  const stock = todosLosJuegos.reduce((s, g) => s + g.stock, 0);          // suma total de unidades
  const bajo  = todosLosJuegos.filter(g => g.stock <= 3).length;           // juegos con poco stock
  const valor = todosLosJuegos.reduce((s, g) => s + g.price * g.stock, 0); // valor total del inventario

  statTitulos.textContent = total;
  statStock.textContent   = stock;
  statBajo.textContent    = bajo;
  statValor.textContent   = `$${valor.toFixed(0)}`;

  // Pinta la tarjeta de rojo si hay juegos con stock bajo
  statCardBajo.classList.toggle('stat-warning', bajo > 0);
}

// Cambia el stock de un juego: actualiza la UI primero (optimista) y luego sincroniza con la API
async function cambiarStock(id, delta) {
  const juego = todosLosJuegos.find(g => g.id == id);
  if (!juego) return;

  const nuevoStock = Math.max(0, juego.stock + delta); // no permite stock negativo

  // Actualización optimista: cambia el dato en memoria y re-renderiza sin esperar la API
  juego.stock = nuevoStock;
  renderizarTabla();

  // Envía PATCH a la API para guardar solo el campo stock
  await fetch(`${API}/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ stock: nuevoStock })
  });
}

// Borra un juego en la API y recarga la tabla
async function borrarJuego(id) {
  await fetch(`${API}/${id}`, { method: 'DELETE' });
  cerrarConfirm(); // cierra el modal de confirmación
  cargarJuegos();  // recarga toda la lista desde la API
}

// Re-renderiza la tabla cada vez que el usuario escribe o cambia el filtro
searchInput.addEventListener('input', renderizarTabla);
filterPlatform.addEventListener('change', renderizarTabla);

// ── Modal Juego: Crear ──────────────────────────────────────
// Prepara el modal en modo "crear": limpia campos y cambia textos
function abrirModalCrear() {
  editandoJuegoId           = null;            // null indica modo crear
  modalJuegoTit.textContent = 'Agregar Juego';
  modalJuegoBtn.textContent = 'Agregar Juego';
  // Limpia todos los campos del formulario a la vez
  jTitle.value = jPlatform.value = jGenre.value = jPrice.value = jStock.value = jYear.value = jPublisher.value = '';
  setCondicion('Nuevo'); // resetea el radio a "Nuevo"
  modalJuego.classList.remove('hidden');
}

// ── Modal Juego: Editar ─────────────────────────────────────
// Prepara el modal en modo "editar": rellena los campos con los datos del juego
function abrirModalEditar(id) {
  const g = todosLosJuegos.find(g => g.id == id); // busca el juego en el estado local
  if (!g) return;

  editandoJuegoId           = g.id;            // guarda el id para el PUT posterior
  modalJuegoTit.textContent = 'Editar Juego';
  modalJuegoBtn.textContent = 'Guardar Cambios';

  // Rellena cada campo con los datos actuales del juego
  jTitle.value     = g.title;
  jPlatform.value  = g.platform;
  jGenre.value     = g.genre;
  jPrice.value     = g.price;
  jStock.value     = g.stock;
  jYear.value      = g.year;
  jPublisher.value = g.publisher;
  setCondicion(g.condition); // marca el radio correcto (Nuevo/Usado)
  modalJuego.classList.remove('hidden');
}

// Oculta el modal de juego
function cerrarModalJuego() {
  modalJuego.classList.add('hidden');
}

// Actualiza visualmente los botones radio de condición (Nuevo/Usado)
function setCondicion(val) {
  const radios = document.querySelectorAll('input[name="condition"]');
  radios.forEach(r => { r.checked = (r.value === val); }); // marca el correcto
  radioNuevo.classList.toggle('active', val === 'Nuevo');   // aplica estilo activo
  radioUsado.classList.toggle('active', val === 'Usado');
}

// Actualiza el estilo del radio cuando el usuario hace clic
document.querySelectorAll('input[name="condition"]').forEach(r => {
  r.addEventListener('change', () => setCondicion(r.value));
});

// Eventos para abrir y cerrar el modal de juego
btnAgregar.addEventListener('click', abrirModalCrear);
document.getElementById('modal-juego-cerrar').addEventListener('click', cerrarModalJuego);
document.getElementById('modal-juego-cancelar').addEventListener('click', cerrarModalJuego);
modalJuego.addEventListener('click', cerrarModalJuego); // clic en el fondo oscuro lo cierra

// Guardar juego: crea (POST) o edita (PUT) según editandoJuegoId
modalJuegoBtn.addEventListener('click', async () => {
  // Lee el radio seleccionado (Nuevo o Usado)
  const condition = document.querySelector('input[name="condition"]:checked')?.value || 'Nuevo';

  // Construye el objeto con los datos del formulario, convirtiendo a los tipos correctos
  const datos = {
    title:     jTitle.value.trim(),
    platform:  jPlatform.value,
    genre:     jGenre.value,
    price:     parseFloat(jPrice.value),  // string → número decimal
    stock:     parseInt(jStock.value),    // string → número entero
    year:      parseInt(jYear.value),
    publisher: jPublisher.value.trim(),
    condition
  };

  // Validación básica: campos obligatorios no vacíos y números válidos
  if (!datos.title || !datos.platform || !datos.genre || isNaN(datos.price) || isNaN(datos.stock)) {
    alert('Por favor completa todos los campos obligatorios.');
    return;
  }

  if (editandoJuegoId) {
    // Modo editar: PUT reemplaza el juego completo por el nuevo objeto
    await fetch(`${API}/${editandoJuegoId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...datos, id: editandoJuegoId }) // incluye el id para JSON Server
    });
  } else {
    // Modo crear: POST agrega un juego nuevo
    await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    });
  }

  cerrarModalJuego();
  cargarJuegos(); // recarga la tabla para reflejar los cambios
});

// ── Modal de confirmación (borrar juego) ────────────────────
// Muestra el modal con un mensaje y guarda la función a ejecutar si el usuario confirma
function abrirConfirm(msg, callback) {
  confirmMsg.textContent = msg;
  confirmCallback        = callback; // guarda la acción pendiente
  modalConfirm.classList.remove('hidden');
}

// Cierra el modal y limpia la función pendiente
function cerrarConfirm() {
  modalConfirm.classList.add('hidden');
  confirmCallback = null;
}

// Si confirma, ejecuta el callback (ej: borrarJuego)
confirmOk.addEventListener('click', () => { if (confirmCallback) confirmCallback(); });
confirmCancel.addEventListener('click', cerrarConfirm);
modalConfirm.addEventListener('click', cerrarConfirm); // clic en fondo oscuro cancela

// Evita que clic dentro del diálogo propague al overlay y lo cierre
document.querySelector('#modal-confirm .confirm-dialog').addEventListener('click', e => e.stopPropagation());
