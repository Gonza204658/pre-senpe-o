import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { gamesAPI } from '../utils/api'
import GameModal from '../components/GameModal'
import './Dashboard.css'

export default function Dashboard() {
  const { can } = useAuth()
  const [games, setGames] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterPlatform, setFilterPlatform] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [editingGame, setEditingGame] = useState(null)
  const [deleteConfirm, setDeleteConfirm] = useState(null)

  const loadGames = async () => {
    try {
      setLoading(true)
      const data = await gamesAPI.getAll()
      setGames(data)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadGames() }, [])

  const handleSave = async (formData) => {
    if (editingGame) {
      await gamesAPI.update(editingGame.id, { ...formData, id: editingGame.id })
    } else {
      await gamesAPI.create(formData)
    }
    setModalOpen(false)
    setEditingGame(null)
    loadGames()
  }

  const handleEdit = (game) => {
    setEditingGame(game)
    setModalOpen(true)
  }

  const handleDelete = async (id) => {
    await gamesAPI.delete(id)
    setDeleteConfirm(null)
    loadGames()
  }

  const handleStockChange = async (game, delta) => {
    const newStock = Math.max(0, game.stock + delta)
    await gamesAPI.patch(game.id, { stock: newStock })
    setGames(prev => prev.map(g => g.id === game.id ? { ...g, stock: newStock } : g))
  }

  // Filtros
  const platforms = [...new Set(games.map(g => g.platform))]
  const filtered = games.filter(g => {
    const matchSearch = g.title.toLowerCase().includes(search.toLowerCase()) ||
      g.publisher.toLowerCase().includes(search.toLowerCase())
    const matchPlatform = !filterPlatform || g.platform === filterPlatform
    return matchSearch && matchPlatform
  })

  // Stats
  const totalGames = games.length
  const totalStock = games.reduce((s, g) => s + g.stock, 0)
  const lowStock = games.filter(g => g.stock <= 3).length
  const totalValue = games.reduce((s, g) => s + g.price * g.stock, 0)

  return (
    <div className="dashboard">
      {/* Stats */}
      <div className="stats-grid animate-in">
        <div className="stat-card">
          <span className="stat-value">{totalGames}</span>
          <span className="stat-label">Títulos</span>
        </div>
        <div className="stat-card">
          <span className="stat-value">{totalStock}</span>
          <span className="stat-label">Unidades en Stock</span>
        </div>
        <div className={`stat-card ${lowStock > 0 ? 'stat-warning' : ''}`}>
          <span className="stat-value">{lowStock}</span>
          <span className="stat-label">Stock Bajo (≤3)</span>
        </div>
        <div className="stat-card stat-accent">
          <span className="stat-value">${totalValue.toFixed(0)}</span>
          <span className="stat-label">Valor Total</span>
        </div>
      </div>

      {/* Header + filtros */}
      <div className="section-header animate-in" style={{animationDelay:'0.1s'}}>
        <h2 className="section-title">Inventario</h2>
        <div className="header-actions">
          <input
            className="form-input search-input"
            placeholder="🔍 Buscar juego o editorial..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <select className="form-input filter-select" value={filterPlatform} onChange={e => setFilterPlatform(e.target.value)}>
            <option value="">Todas las plataformas</option>
            {platforms.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
          {can.create && (
            <button className="btn btn-primary" onClick={() => { setEditingGame(null); setModalOpen(true) }}>
              + Agregar Juego
            </button>
          )}
        </div>
      </div>

      {/* Tabla */}
      {loading ? (
        <div className="loading">Cargando inventario...</div>
      ) : (
        <div className="table-wrap animate-in" style={{animationDelay:'0.2s'}}>
          <table className="games-table">
            <thead>
              <tr>
                <th>Título</th>
                <th>Plataforma</th>
                <th>Género</th>
                <th>Editorial</th>
                <th>Condición</th>
                <th>Precio</th>
                <th>Stock</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan="8" className="empty">No se encontraron juegos</td></tr>
              ) : (
                filtered.map(game => (
                  <tr key={game.id} className={game.stock <= 3 ? 'row-warning' : ''}>
                    <td className="td-title">
                      <span className="game-title">{game.title}</span>
                      <span className="game-year">{game.year}</span>
                    </td>
                    <td><span className="platform-tag">{game.platform}</span></td>
                    <td className="td-genre">{game.genre}</td>
                    <td className="td-muted">{game.publisher}</td>
                    <td><span className={`badge badge-${game.condition.toLowerCase()}`}>{game.condition}</span></td>
                    <td className="td-price">${game.price.toFixed(2)}</td>
                    <td>
                      <div className="stock-control">
                        {can.edit && (
                          <button className="stock-btn" onClick={() => handleStockChange(game, -1)}>−</button>
                        )}
                        <span className={`stock-num ${game.stock <= 3 ? 'stock-low' : ''}`}>{game.stock}</span>
                        {can.edit && (
                          <button className="stock-btn" onClick={() => handleStockChange(game, 1)}>+</button>
                        )}
                      </div>
                    </td>
                    <td>
                      <div className="actions">
                        {can.edit && (
                          <button className="btn btn-secondary btn-sm" onClick={() => handleEdit(game)}>Editar</button>
                        )}
                        {can.delete && (
                          <button className="btn btn-danger btn-sm" onClick={() => setDeleteConfirm(game)}>Borrar</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal crear/editar */}
      {modalOpen && (
        <GameModal
          game={editingGame}
          onSave={handleSave}
          onClose={() => { setModalOpen(false); setEditingGame(null) }}
        />
      )}

      {/* Confirm delete */}
      {deleteConfirm && (
        <div className="modal-overlay" onClick={() => setDeleteConfirm(null)}>
          <div className="confirm-dialog" onClick={e => e.stopPropagation()}>
            <h3>¿Eliminar juego?</h3>
            <p>Se eliminará <strong>{deleteConfirm.title}</strong> del inventario.</p>
            <div className="confirm-actions">
              <button className="btn btn-secondary" onClick={() => setDeleteConfirm(null)}>Cancelar</button>
              <button className="btn btn-danger" onClick={() => handleDelete(deleteConfirm.id)}>Sí, eliminar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
