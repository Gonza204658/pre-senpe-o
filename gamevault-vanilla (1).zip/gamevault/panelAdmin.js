// ── Selección de elementos del DOM ─────────────────────────
const navUsuariosBtn      = document.getElementById('nav-usuarios');      // enlace "Usuarios" en el navbar
const vistaUsuarios       = document.getElementById('vista-usuarios');    // sección completa de usuarios
const usersTbody          = document.getElementById('users-tbody');       // cuerpo de la tabla de usuarios
const btnCrearUsuario     = document.getElementById('btn-crear-usuario'); // botón "+ Crear Usuario"

// Modal de crear/editar usuario
const modalUsuario        = document.getElementById('modal-usuario');
const modalUsuarioTit     = document.getElementById('modal-usuario-titulo');
const modalUsuarioGuardar = document.getElementById('modal-usuario-guardar');
const modalUsuarioCerrar  = document.getElementById('modal-usuario-cerrar');
const modalUsuarioCxl     = document.getElementById('modal-usuario-cancelar');

// Campos del formulario dentro del modal
const uName     = document.getElementById('u-name');
const uUsername = document.getElementById('u-username');
const uPassword = document.getElementById('u-password');
const uRole     = document.getElementById('u-role');

const API_USERS = '/api/users'; // ruta base de la API para usuarios

// ── Estado ──────────────────────────────────────────────────
let editandoUserId  = null; // id del usuario en edición (null = modo crear)
let usuarioEditando = null; // objeto completo del usuario en edición (para conservar la contraseña si no se cambia)

// ── Navegación ──────────────────────────────────────────────
// Cuando se hace clic en "Usuarios" del navbar, muestra esa vista y carga los datos
navUsuariosBtn.addEventListener('click', (e) => {
  e.preventDefault();
  mostrarVista('usuarios'); // función definida en dashboard.js (compartida globalmente)
  cargarUsuarios();
});

// ── Cargar tabla de usuarios ────────────────────────────────
// Pide todos los usuarios a la API y los pinta en la tabla
async function cargarUsuarios() {
  usersTbody.innerHTML = `<tr><td colspan="4" class="loading">Cargando usuarios...</td></tr>`;
  try {
    const res   = await fetch(API_USERS);
    const users = await res.json();
    renderizarUsuarios(users);
  } catch {
    usersTbody.innerHTML = `<tr><td colspan="4" class="loading">Error al cargar usuarios.</td></tr>`;
  }
}

// Genera el HTML de cada fila de la tabla de usuarios
function renderizarUsuarios(users) {
  if (users.length === 0) {
    usersTbody.innerHTML = `<tr><td colspan="4" class="empty">No hay usuarios.</td></tr>`;
    return;
  }

  // Construye una fila por cada usuario con avatar, nombre, username, rol y acciones
  usersTbody.innerHTML = users.map(u => `
    <tr>
      <td>
        <div class="td-avatar">
          <!-- Avatar con la inicial del nombre en mayúscula -->
          <div class="user-avatar">${u.name.charAt(0).toUpperCase()}</div>
          <span>${u.name}</span>
        </div>
      </td>
      <td class="td-muted">@${u.username}</td>
      <td><span class="badge badge-${u.role}">${u.role}</span></td>
      <td style="text-align:right">
        <div class="actions" style="justify-content:flex-end">
          <!-- data-editar-user y data-borrar-user guardan el id para los event listeners -->
          <button class="btn btn-secondary btn-sm" data-editar-user="${u.id}">Editar</button>
          <button class="btn btn-danger btn-sm" data-borrar-user="${u.id}" data-nombre-user="${u.name}">Borrar</button>
        </div>
      </td>
    </tr>
  `).join('');

  // Asigna el evento "editar" a cada botón recién creado
  usersTbody.querySelectorAll('[data-editar-user]').forEach(btn => {
    btn.addEventListener('click', () => {
      const u = users.find(u => u.id == btn.dataset.editarUser); // busca el usuario por id
      if (u) abrirModalUsuario(u); // abre el modal con los datos del usuario
    });
  });

  // Asigna el evento "borrar" a cada botón recién creado
  usersTbody.querySelectorAll('[data-borrar-user]').forEach(btn => {
    btn.addEventListener('click', () => {
      // Pide confirmación nativa antes de borrar
      if (!confirm(`¿Eliminar al usuario "${btn.dataset.nombreUser}"?`)) return;
      borrarUsuario(btn.dataset.borrarUser);
    });
  });
}

// ── Modal de usuario ─────────────────────────────────────────
// Abre el modal en modo crear (user = null) o editar (user = objeto)
function abrirModalUsuario(user = null) {
  editandoUserId  = user ? user.id : null; // guarda el id si es edición
  usuarioEditando = user;                   // guarda el objeto completo para recuperar contraseña si no cambia

  if (user) {
    // Modo editar: rellena los campos con los datos actuales
    modalUsuarioTit.textContent     = 'Editar Usuario';
    modalUsuarioGuardar.textContent = 'Guardar Cambios';
    uName.value     = user.name;
    uUsername.value = user.username;
    uPassword.value = '';
    uPassword.placeholder = '•••••••• (dejar vacío para no cambiar)'; // contraseña opcional en edición
    uRole.value     = user.role;
  } else {
    // Modo crear: limpia todos los campos
    modalUsuarioTit.textContent     = 'Crear Usuario';
    modalUsuarioGuardar.textContent = 'Crear Usuario';
    uName.value = uUsername.value = uPassword.value = '';
    uPassword.placeholder = '••••••••'; // contraseña obligatoria en creación
    uRole.value = 'empleado'; // rol por defecto
  }

  modalUsuario.classList.remove('hidden'); // muestra el modal
}

// Oculta el modal y limpia el estado de edición
function cerrarModalUsuario() {
  modalUsuario.classList.add('hidden');
  editandoUserId  = null;
  usuarioEditando = null;
}

// Eventos para abrir y cerrar el modal de usuario
btnCrearUsuario.addEventListener('click', () => abrirModalUsuario(null));
modalUsuarioCerrar.addEventListener('click', cerrarModalUsuario);
modalUsuarioCxl.addEventListener('click', cerrarModalUsuario);
modalUsuario.addEventListener('click', cerrarModalUsuario); // clic en el fondo oscuro lo cierra

// Evita que clic dentro del modal propague al overlay y lo cierre
document.querySelector('#modal-usuario .modal').addEventListener('click', e => e.stopPropagation());

// ── Guardar usuario (crear o editar) ───────────────────────
modalUsuarioGuardar.addEventListener('click', async () => {
  const nombre   = uName.value.trim();
  const username = uUsername.value.trim();
  const password = uPassword.value.trim();
  const role     = uRole.value;

  // Validación: nombre y username son siempre obligatorios
  if (!nombre || !username) {
    alert('Nombre y username son obligatorios.');
    return;
  }

  // En modo crear, la contraseña también es obligatoria
  if (!editandoUserId && !password) {
    alert('La contraseña es obligatoria para crear un usuario.');
    return;
  }

  let body;

  if (editandoUserId) {
    // Modo editar: PUT reemplaza el usuario completo
    // Si no escribió nueva contraseña, conserva la anterior
    body = {
      id:       String(editandoUserId),
      name:     nombre,
      username,
      password: password || usuarioEditando.password, // mantiene contraseña original si campo vacío
      role
    };
    await fetch(`${API_USERS}/${editandoUserId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } else {
    // Modo crear: POST agrega el nuevo usuario
    body = { name: nombre, username, password, role };
    await fetch(API_USERS, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  }

  cerrarModalUsuario();
  cargarUsuarios(); // recarga la tabla para reflejar el cambio
});

// ── Borrar usuario ───────────────────────────────────────────
async function borrarUsuario(id) {
  try {
    await fetch(`${API_USERS}/${id}`, { method: 'DELETE' });
  } catch {
    alert('Error al eliminar el usuario.');
  }
  cargarUsuarios(); // recarga la tabla tras borrar
}
