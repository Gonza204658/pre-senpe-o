const form      = document.getElementById('loginForm');
const btnLogin  = document.getElementById('login-btn');
const errorBox  = document.getElementById('login-error');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = form.username.value.trim();
  const password = form.password.value.trim();

  btnLogin.disabled    = true;
  btnLogin.textContent = 'Entrando...';
  errorBox.classList.add('hidden');

  try {
    const res   = await fetch(`/api/users?username=${username}&password=${password}`);
    const users = await res.json();

    if (users.length === 0) {
      errorBox.textContent = '⚠ Usuario o contraseña incorrectos';
      errorBox.classList.remove('hidden');
      return;
    }

    // Guardar sesión sin contraseña
    const { password: _, ...safeUser } = users[0];
    localStorage.setItem('gamevault_user', JSON.stringify(safeUser));

    // Disparar evento para que dashboard y panelAdmin sepan que hubo login
    window.dispatchEvent(new CustomEvent('gv:login', { detail: safeUser }));

  } catch {
    errorBox.textContent = '⚠ Error al conectar con el servidor';
    errorBox.classList.remove('hidden');
  } finally {
    btnLogin.disabled    = false;
    btnLogin.textContent = 'Iniciar Sesión';
  }
});
