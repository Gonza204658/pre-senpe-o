# 🎮 GameVault — Sistema de Inventario

Sistema de inventario para una tienda de videojuegos. Aplicación SPA construida con React + Vite, API REST con JSON Server, y persistencia de sesión con localStorage.

---

## 🚀 Instalación y ejecución

### Requisitos
- Node.js 18+
- npm

### Pasos

```bash
# 1. Clonar el repositorio
git clone https://github.com/TU_USUARIO/gamevault.git
cd gamevault

# 2. Instalar dependencias
npm install

# 3. Correr el proyecto (frontend + API al mismo tiempo)
npm run dev
```

El frontend corre en: `http://localhost:5173`  
La API corre en: `http://localhost:3001`

---

## 🔑 Credenciales de prueba

| Usuario | Contraseña | Rol |
|---------|-----------|-----|
| `admin` | `admin123` | Admin |
| `empleado` | `emp123` | Empleado |

---

## 📁 Estructura del proyecto

```
gamevault/
├── db.json                  # Base de datos (JSON Server)
├── vite.config.js           # Configuración de Vite + proxy API
├── index.html               # Punto de entrada HTML
└── src/
    ├── main.jsx             # Punto de entrada React
    ├── App.jsx              # Rutas principales (React Router)
    ├── index.css            # Estilos globales y variables CSS
    ├── context/
    │   └── AuthContext.jsx  # Estado global de autenticación + sesión
    ├── utils/
    │   └── api.js           # Funciones CRUD para la API
    ├── components/
    │   ├── Layout.jsx       # Wrapper con Navbar
    │   ├── Navbar.jsx       # Barra de navegación
    │   ├── ProtectedRoute.jsx # Guardia de rutas por auth y rol
    │   └── GameModal.jsx    # Modal de crear/editar juego
    └── pages/
        ├── Login.jsx        # Página de login
        ├── Dashboard.jsx    # Inventario con CRUD completo
        └── Usuarios.jsx     # Gestión de usuarios (solo admin)
```

---

## 🏗️ Arquitectura SPA

El proyecto usa **React Router DOM v6** para navegación del lado del cliente (sin recargas de página).

- `/login` → página pública
- `/dashboard` → inventario (requiere login)
- `/usuarios` → gestión de usuarios (requiere rol admin)

El componente `ProtectedRoute` evalúa si el usuario está autenticado antes de renderizar la ruta. Si no lo está, redirige a `/login`.

---

## 🔄 CRUD y consumo de API

La API está en `src/utils/api.js` y consume el servidor JSON Server en `http://localhost:3001`.

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/games` | Listar todos los juegos |
| GET | `/api/games/:id` | Obtener un juego |
| POST | `/api/games` | Crear juego (solo admin) |
| PUT | `/api/games/:id` | Editar juego completo |
| PATCH | `/api/games/:id` | Editar stock (admin y empleado) |
| DELETE | `/api/games/:id` | Eliminar juego (solo admin) |
| GET | `/api/users?username=X` | Buscar usuario para login |

---

## 💾 Persistencia de sesión

La sesión del usuario se guarda en `localStorage` con la clave `gamevault_user`.

- **Al iniciar sesión:** se guarda el usuario (sin contraseña) en localStorage.
- **Al recargar la página:** `AuthContext` lee localStorage automáticamente y restaura la sesión.
- **Al cerrar sesión:** se borra el item de localStorage.

```js
// Guardar sesión
localStorage.setItem('gamevault_user', JSON.stringify(safeUser))

// Leer sesión al arrancar
const saved = localStorage.getItem('gamevault_user')
const user = saved ? JSON.parse(saved) : null

// Cerrar sesión
localStorage.removeItem('gamevault_user')
```

---

## 👥 Roles y permisos

| Acción | Admin | Empleado |
|--------|-------|---------|
| Ver inventario | ✅ | ✅ |
| Editar stock (+/-) | ✅ | ✅ |
| Editar juego | ✅ | ✅ |
| Agregar juego | ✅ | ❌ |
| Eliminar juego | ✅ | ❌ |
| Ver página de usuarios | ✅ | ❌ |

Los permisos se manejan en `AuthContext` con el objeto `can`:

```js
const can = {
  create: isAdmin,      // solo admin puede crear
  edit: !!user,         // admin y empleado pueden editar
  delete: isAdmin,      // solo admin puede eliminar
  viewAll: !!user,
}
```

---

## 🛠️ Scripts disponibles

```bash
npm run dev      # Corre frontend + API (modo desarrollo)
npm run build    # Compila el frontend para producción
npm run api      # Corre solo la API (JSON Server)
```

---

## 🔧 Personalización rápida

Para adaptar este proyecto a otro tema de inventario:

1. **Cambiar la entidad**: renombra `games` en `db.json` y `api.js` por lo que necesites (ej: `libros`, `productos`).
2. **Cambiar campos**: edita el formulario en `GameModal.jsx` y los campos de la tabla en `Dashboard.jsx`.
3. **Cambiar datos de prueba**: edita `db.json`.
4. **Cambiar nombre y logo**: edita `Navbar.jsx`, `Login.jsx`, e `index.html`.

---

## 📦 Dependencias principales

| Paquete | Versión | Uso |
|---------|---------|-----|
| react | 18 | Framework UI |
| react-router-dom | 6 | Enrutamiento SPA |
| vite | 5 | Bundler y dev server |
| json-server | 0.17 | API REST mock |
| concurrently | 8 | Correr múltiples procesos |
