const BASE = '/api/games'

export const gamesAPI = {
  // GET all
  getAll: async () => {
    const res = await fetch(BASE)
    if (!res.ok) throw new Error('Error al obtener juegos')
    return res.json()
  },

  // GET by id
  getById: async (id) => {
    const res = await fetch(`${BASE}/${id}`)
    if (!res.ok) throw new Error('Juego no encontrado')
    return res.json()
  },

  // POST - crear
  create: async (data) => {
    const res = await fetch(BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    if (!res.ok) throw new Error('Error al crear juego')
    return res.json()
  },

  // PUT - editar completo
  update: async (id, data) => {
    const res = await fetch(`${BASE}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    if (!res.ok) throw new Error('Error al actualizar juego')
    return res.json()
  },

  // PATCH - editar parcial (ej: solo stock)
  patch: async (id, data) => {
    const res = await fetch(`${BASE}/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    if (!res.ok) throw new Error('Error al actualizar')
    return res.json()
  },

  // DELETE
  delete: async (id) => {
    const res = await fetch(`${BASE}/${id}`, { method: 'DELETE' })
    if (!res.ok) throw new Error('Error al eliminar juego')
    return true
  }
}
