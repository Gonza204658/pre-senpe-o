import { useState, useEffect } from 'react'
import './Usuarios.css'

export default function Usuarios() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/users')
      .then(r => r.json())
      .then(data => {
        // No mostrar contraseñas
        setUsers(data.map(({ password, ...u }) => u))
      })
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="usuarios-page">
      <h2 className="section-title animate-in">Gestión de Usuarios</h2>
      <p className="page-desc animate-in">Vista exclusiva para administradores.</p>

      {loading ? (
        <div className="loading">Cargando usuarios...</div>
      ) : (
        <div className="users-grid animate-in" style={{animationDelay:'0.1s'}}>
          {users.map(user => (
            <div key={user.id} className="user-card">
              <div className="user-avatar">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div className="user-details">
                <span className="user-card-name">{user.name}</span>
                <span className="user-card-username">@{user.username}</span>
              </div>
              <span className={`badge badge-${user.role}`}>{user.role}</span>
            </div>
          ))}
        </div>
      )}

      <div className="roles-info animate-in" style={{animationDelay:'0.2s'}}>
        <h3>Permisos por Rol</h3>
        <table className="roles-table">
          <thead>
            <tr>
              <th>Acción</th>
              <th>Admin</th>
              <th>Empleado</th>
            </tr>
          </thead>
          <tbody>
            {[
              ['Ver inventario', true, true],
              ['Editar stock', true, true],
              ['Editar juego', true, true],
              ['Agregar juego', true, false],
              ['Eliminar juego', true, false],
              ['Ver usuarios', true, false],
            ].map(([action, admin, emp]) => (
              <tr key={action}>
                <td>{action}</td>
                <td className="perm-cell">{admin ? '✅' : '❌'}</td>
                <td className="perm-cell">{emp ? '✅' : '❌'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
